import "flag-icons/css/flag-icons.min.css";
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import './styles/global.css'
import { BrowserRouter } from "react-router-dom";




createRoot(document.getElementById('root')).render(
  <>
  <BrowserRouter>
    <App />
  </BrowserRouter>
  </>,
)
