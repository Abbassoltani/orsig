import React from 'react'
import { Typewriter } from 'react-simple-typewriter'
import Title from '../components/Title'

function Home() {
  return (
    <>
    <header className='container '>

        <div className="header position-relative">

        </div>
    
            <div className="header-content ">
                <h1>
                <Typewriter
                    words={["ORSIG"]}
                    delaySpeed={3000}
                    loop={true}
                    deleteSpeed={70}
                    typeSpeed={40}
                    cursor={true}

                />

                </h1>
                <h3>فیلترهای خودرویی و صنعتی اُرسیگ</h3>
            </div>

      <Title/>
  
    </header>
    <div className="container">
      
    </div>

     
    </>
  )
}

export default Home
