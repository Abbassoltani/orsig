import React from 'react'

function Title() {
  return (
    <>
    <div className="title-banner d-flex">
        <img src="../../public/assets/bordertitle-right.png" alt="" />
        <div className="title-content">
            <h3>درباره ما</h3>
            <h4>About Us</h4>
        </div>
        <img src="../../public/assets/bordertitle-left.png" alt="" />

    </div>
      
    </>
  )
}

export default Title
